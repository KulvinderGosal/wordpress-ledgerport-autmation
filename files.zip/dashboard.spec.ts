/**
 * LedgerPort WordPress Plugin — Dashboard Screen Tests
 *
 * Covers:
 *  - Page load & title verification
 *  - Header / branding
 *  - Date filter toolbar (dropdown, date range, last-sync badge, Sync Now CTA)
 *  - Stats cards: Sync Health, Orders, Needs Attention
 *  - Data Health Overview section (counts + status badges)
 *  - Recent Activity feed (entries, badges, View All CTA)
 *  - Setup Checklist sidebar widget
 *  - Connections sidebar widget
 *  - Configuration sidebar widget
 *  - Sidebar navigation (all 7 plugin menu items)
 *  - Footer
 *
 * Test URL : https://qastaging.pushengage.com/wp-admin/admin.php?page=ledgerport
 * Auth     : kgosal / !letmeIn@123=
 */

import { test, expect, Page } from '@playwright/test';
import { loginAsAdmin, goToPluginPage, PLUGIN_PAGES } from './helpers/auth';

// ─── Fixture: log in once, then navigate to dashboard ────────────────────────

test.describe('LedgerPort Dashboard', () => {
  let page: Page;

  test.beforeAll(async ({ browser }) => {
    const context = await browser.newContext();
    page = await context.newPage();
    await loginAsAdmin(page);
    await goToPluginPage(page, PLUGIN_PAGES.dashboard);
  });

  test.afterAll(async () => {
    await page.close();
  });

  // ─── 1. PAGE LOAD & TITLE ──────────────────────────────────────────────────

  test.describe('1. Page Load & Title', () => {
    test('LP-DASH-001 | Page title contains "Dashboard"', async () => {
      await expect(page).toHaveTitle(/Dashboard/i);
    });

    test('LP-DASH-002 | URL resolves to dashboard page without redirect', async () => {
      expect(page.url()).toContain('page=ledgerport');
      expect(page.url()).not.toContain('wp-login.php');
    });

    test('LP-DASH-003 | Page loads without JS console errors', async () => {
      const errors: string[] = [];
      page.on('console', msg => {
        if (msg.type() === 'error') errors.push(msg.text());
      });
      // Re-navigate to capture any load-time errors
      await page.reload({ waitUntil: 'networkidle' });
      expect(errors.filter(e => !e.includes('favicon'))).toHaveLength(0);
    });
  });

  // ─── 2. HEADER / BRANDING ─────────────────────────────────────────────────

  test.describe('2. Header Branding', () => {
    test('LP-DASH-004 | LedgerPort logo is visible', async () => {
      const logo = page.locator('img[alt*="LedgerPort"], .ledgerport-logo, header img').first();
      await expect(logo).toBeVisible();
    });

    test('LP-DASH-005 | "LedgerPort" brand name is visible in the header', async () => {
      // The plugin header area contains the brand name
      await expect(page.locator('header, .ledgerport-header, #wpbody').first())
        .toContainText('LedgerPort');
    });

    test('LP-DASH-006 | Notification bell icon is visible in header', async () => {
      const bell = page.locator('button[aria-label*="notification"], .notification-bell, svg[aria-label*="bell"]').first();
      await expect(bell).toBeVisible();
    });

    test('LP-DASH-007 | Dark/light mode toggle icon is visible in header', async () => {
      // Moon/sun icon for theme toggle
      const modeToggle = page.locator('button[aria-label*="mode"], button[aria-label*="theme"], .theme-toggle').first();
      await expect(modeToggle).toBeVisible();
    });

    test('LP-DASH-008 | Help/question mark icon is visible in header', async () => {
      const helpIcon = page.locator('button[aria-label*="help"], a[aria-label*="help"], .help-icon').first();
      await expect(helpIcon).toBeVisible();
    });
  });

  // ─── 3. OVERVIEW SECTION HEADING ──────────────────────────────────────────

  test.describe('3. Overview Section Heading', () => {
    test('LP-DASH-009 | "Overview" heading is visible', async () => {
      await expect(page.getByRole('heading', { name: /overview/i })).toBeVisible();
    });

    test('LP-DASH-010 | Sub-heading text is correct', async () => {
      await expect(page.getByText('Sync health, recent activity, and what needs your attention.')).toBeVisible();
    });
  });

  // ─── 4. DATE FILTER TOOLBAR ───────────────────────────────────────────────

  test.describe('4. Date Filter Toolbar', () => {
    test('LP-DASH-011 | "Syncing your store" label is visible', async () => {
      await expect(page.getByText('Syncing your store')).toBeVisible();
    });

    test('LP-DASH-012 | Date range dropdown is visible and defaults to "Last 7 days"', async () => {
      const dropdown = page.getByRole('combobox').or(
        page.locator('select, [role="listbox"], .date-range-select')
      ).first();
      await expect(dropdown).toBeVisible();
      // Verify the default displayed value
      await expect(page.getByText('Last 7 days')).toBeVisible();
    });

    test('LP-DASH-013 | Date range dropdown opens when clicked', async () => {
      const dropdown = page.locator('select, [role="combobox"], .date-range-select').first();
      await dropdown.click();
      // At least one option should appear
      const options = page.locator('option, [role="option"], li').filter({ hasText: /days|week|month/i });
      await expect(options.first()).toBeVisible();
      // Close by pressing Escape
      await page.keyboard.press('Escape');
    });

    test('LP-DASH-014 | Active date range "May 9, 2026 – May 15, 2026" is displayed', async () => {
      await expect(page.getByText(/May \d+, \d{4}\s*[–-]\s*May \d+, \d{4}/)).toBeVisible();
    });

    test('LP-DASH-015 | Calendar icon is visible next to the date range', async () => {
      const calIcon = page.locator('svg[aria-label*="calendar"], .calendar-icon, [data-icon="calendar"]').first();
      await expect(calIcon).toBeVisible();
    });

    test('LP-DASH-016 | "Last sync: X minutes ago" badge is visible', async () => {
      await expect(page.getByText(/last sync:/i)).toBeVisible();
    });

    test('LP-DASH-017 | Last sync status indicator dot is green (connected)', async () => {
      const dot = page.locator('.sync-status-dot, .status-dot--green, [class*="status"][class*="green"]').first();
      await expect(dot).toBeVisible();
    });

    test('LP-DASH-018 | "Sync now" button is visible and enabled', async () => {
      const syncBtn = page.getByRole('button', { name: /sync now/i });
      await expect(syncBtn).toBeVisible();
      await expect(syncBtn).toBeEnabled();
    });

    test('LP-DASH-019 | "Sync now" button triggers a sync action on click', async () => {
      const syncBtn = page.getByRole('button', { name: /sync now/i });
      await syncBtn.click();
      // After clicking, either a loading state appears or a toast/notification
      const feedbackIndicator = page.locator(
        '.syncing, [aria-label*="syncing"], .toast, .notice, [class*="loading"]'
      ).first();
      // We don't assert exact state — just verify the button click does not cause a page error
      await expect(page).not.toHaveTitle(/error|404|500/i);
      await page.waitForLoadState('networkidle');
    });
  });

  // ─── 5. SYNC HEALTH CARD ──────────────────────────────────────────────────

  test.describe('5. Sync Health Card', () => {
    test('LP-DASH-020 | "SYNC HEALTH" label is visible', async () => {
      await expect(page.getByText('SYNC HEALTH')).toBeVisible();
    });

    test('LP-DASH-021 | Success rate percentage is displayed (e.g. "92% success rate")', async () => {
      await expect(page.getByText(/\d+% success rate/i)).toBeVisible();
    });

    test('LP-DASH-022 | Total syncs count is displayed (e.g. "100 total syncs")', async () => {
      await expect(page.getByText(/\d+ total syncs/i)).toBeVisible();
    });

    test('LP-DASH-023 | "View error log →" link is visible', async () => {
      const link = page.getByRole('link', { name: /view error log/i });
      await expect(link).toBeVisible();
    });

    test('LP-DASH-024 | "View error log →" link navigates to Audit Logs page', async () => {
      const link = page.getByRole('link', { name: /view error log/i });
      const href = await link.getAttribute('href');
      expect(href).toContain('ledgerport');
    });

    test('LP-DASH-025 | Sync Health card has a settings/gear icon', async () => {
      // The card has an icon in the top-right corner
      const card = page.locator('.sync-health-card, [data-card="sync-health"]')
        .or(page.getByText('SYNC HEALTH').locator('..').locator('..'));
      await expect(card.locator('svg, img').first()).toBeVisible();
    });
  });

  // ─── 6. ORDERS CARD ───────────────────────────────────────────────────────

  test.describe('6. Orders Card', () => {
    test('LP-DASH-026 | "ORDERS" label is visible', async () => {
      await expect(page.getByText('ORDERS').first()).toBeVisible();
    });

    test('LP-DASH-027 | Orders count is displayed (e.g. "6 orders")', async () => {
      await expect(page.getByText(/\d+ orders/i).first()).toBeVisible();
    });

    test('LP-DASH-028 | Orders success rate is displayed (e.g. "100.0% success rate")', async () => {
      // There are 2 success rate texts; the second one belongs to the Orders card
      const successRates = page.getByText(/\d+\.?\d*% success rate/i);
      await expect(successRates.nth(1)).toBeVisible();
    });

    test('LP-DASH-029 | "View report →" link is visible', async () => {
      const link = page.getByRole('link', { name: /view report/i });
      await expect(link).toBeVisible();
    });

    test('LP-DASH-030 | "View report →" link has a valid href', async () => {
      const link = page.getByRole('link', { name: /view report/i });
      const href = await link.getAttribute('href');
      expect(href).toBeTruthy();
      expect(href).toContain('ledgerport');
    });
  });

  // ─── 7. NEEDS ATTENTION CARD ──────────────────────────────────────────────

  test.describe('7. Needs Attention Card', () => {
    test('LP-DASH-031 | "NEEDS ATTENTION" label is visible', async () => {
      await expect(page.getByText('NEEDS ATTENTION')).toBeVisible();
    });

    test('LP-DASH-032 | Items count is displayed (e.g. "1 items")', async () => {
      await expect(page.getByText(/\d+ items/i)).toBeVisible();
    });

    test('LP-DASH-033 | "Issues need your review" sub-text is visible', async () => {
      await expect(page.getByText('Issues need your review')).toBeVisible();
    });

    test('LP-DASH-034 | "Review issues →" link is visible', async () => {
      const link = page.getByRole('link', { name: /review issues/i });
      await expect(link).toBeVisible();
    });

    test('LP-DASH-035 | "Review issues →" link has a valid href', async () => {
      const link = page.getByRole('link', { name: /review issues/i });
      const href = await link.getAttribute('href');
      expect(href).toBeTruthy();
      expect(href).toContain('ledgerport');
    });
  });

  // ─── 8. DATA HEALTH OVERVIEW ──────────────────────────────────────────────

  test.describe('8. Data Health Overview', () => {
    test('LP-DASH-036 | "Data Health Overview" heading is visible', async () => {
      await expect(page.getByText('Data Health Overview')).toBeVisible();
    });

    test('LP-DASH-037 | "PRODUCTS" column label is visible', async () => {
      await expect(page.getByText('PRODUCTS').first()).toBeVisible();
    });

    test('LP-DASH-038 | Products count is a positive number', async () => {
      // The number directly below PRODUCTS label
      const productCount = page.locator('.data-health-overview, .data-health')
        .or(page.getByText('Data Health Overview').locator('..').locator('..'))
        .getByText(/^\d+$/).first();
      const text = await productCount.textContent();
      expect(Number(text)).toBeGreaterThan(0);
    });

    test('LP-DASH-039 | Products status badge shows "Needs attention"', async () => {
      await expect(page.getByText('Needs attention')).toBeVisible();
    });

    test('LP-DASH-040 | "ORDERS" column label is visible in Data Health', async () => {
      // Second occurrence of ORDERS is inside Data Health
      await expect(page.getByText('ORDERS').nth(1)).toBeVisible();
    });

    test('LP-DASH-041 | Orders status badge shows "Healthy"', async () => {
      const healthyBadges = page.getByText('Healthy');
      await expect(healthyBadges.first()).toBeVisible();
    });

    test('LP-DASH-042 | "CUSTOMERS" column label is visible', async () => {
      await expect(page.getByText('CUSTOMERS')).toBeVisible();
    });

    test('LP-DASH-043 | Customers count is a positive number', async () => {
      const customerCount = await page.getByText('CUSTOMERS')
        .locator('..').locator('..').locator('strong, .count, [class*="number"]').first().textContent();
      expect(Number(customerCount)).toBeGreaterThan(0);
    });

    test('LP-DASH-044 | Customers status badge shows "Healthy"', async () => {
      const healthyBadges = page.getByText('Healthy');
      await expect(healthyBadges.nth(1)).toBeVisible();
    });

    test('LP-DASH-045 | "INVENTORY" column label is visible', async () => {
      await expect(page.getByText('INVENTORY')).toBeVisible();
    });

    test('LP-DASH-046 | Inventory status badge shows "Critical"', async () => {
      await expect(page.getByText('Critical')).toBeVisible();
    });

    test('LP-DASH-047 | "Critical" badge has distinct visual styling (red/orange)', async () => {
      const criticalBadge = page.getByText('Critical').first();
      const classes = await criticalBadge.getAttribute('class');
      // Badge should have a red/warning class
      expect(classes).toMatch(/critical|danger|red|error/i);
    });

    test('LP-DASH-048 | "Needs attention" badge has distinct visual styling (yellow/orange)', async () => {
      const badge = page.getByText('Needs attention').first();
      const classes = await badge.getAttribute('class');
      expect(classes).toMatch(/attention|warning|yellow|orange/i);
    });

    test('LP-DASH-049 | "Healthy" badge has distinct visual styling (green)', async () => {
      const badge = page.getByText('Healthy').first();
      const classes = await badge.getAttribute('class');
      expect(classes).toMatch(/healthy|success|green/i);
    });
  });

  // ─── 9. RECENT ACTIVITY FEED ──────────────────────────────────────────────

  test.describe('9. Recent Activity Feed', () => {
    test('LP-DASH-050 | "Recent Activity" heading is visible', async () => {
      await expect(page.getByText('Recent Activity')).toBeVisible();
    });

    test('LP-DASH-051 | "View all" link is visible next to Recent Activity', async () => {
      const link = page.getByRole('link', { name: /view all/i });
      await expect(link).toBeVisible();
    });

    test('LP-DASH-052 | "View all" link navigates to Audit Logs', async () => {
      const link = page.getByRole('link', { name: /view all/i });
      const href = await link.getAttribute('href');
      expect(href).toContain('ledgerport');
    });

    test('LP-DASH-053 | At least one activity entry is rendered', async () => {
      // Each entry contains an event description, a type tag, and a timestamp
      const entries = page.locator('.activity-item, .recent-activity-entry, [class*="activity-row"]')
        .or(page.getByText(/Synced|Updated|Created/).locator('..'));
      await expect(entries.first()).toBeVisible();
    });

    test('LP-DASH-054 | Activity entry: "Synced 41 orders to QuickBooks" is displayed', async () => {
      await expect(page.getByText('Synced 41 orders to QuickBooks')).toBeVisible();
    });

    test('LP-DASH-055 | Activity entry shows "queue_run" tag', async () => {
      await expect(page.getByText('queue_run').first()).toBeVisible();
    });

    test('LP-DASH-056 | Activity entry shows "Order" type label', async () => {
      await expect(page.getByText('Order').first()).toBeVisible();
    });

    test('LP-DASH-057 | Activity entry shows relative timestamp (e.g. "X minutes ago")', async () => {
      await expect(page.getByText(/minutes ago|hour ago|hours ago|day ago|days ago/i).first()).toBeVisible();
    });

    test('LP-DASH-058 | "success" status badge is visible on successful entries', async () => {
      await expect(page.getByText('success').first()).toBeVisible();
    });

    test('LP-DASH-059 | "partial_success" status badge is visible', async () => {
      await expect(page.getByText('partial_success')).toBeVisible();
    });

    test('LP-DASH-060 | "failed" status badge is visible on failed entries', async () => {
      await expect(page.getByText('failed').first()).toBeVisible();
    });

    test('LP-DASH-061 | Entry "Synced 42 orders to QuickBooks" is visible', async () => {
      await expect(page.getByText('Synced 42 orders to QuickBooks')).toBeVisible();
    });

    test('LP-DASH-062 | Entry \'Updated product mapping "266"\' is visible', async () => {
      await expect(page.getByText(/Updated product mapping "266"/)).toBeVisible();
    });

    test('LP-DASH-063 | Entry "mapping_update" tag is visible', async () => {
      await expect(page.getByText('mapping_update')).toBeVisible();
    });

    test('LP-DASH-064 | Entry "Synced 55 of 58 products to QuickBooks (3 failed)" is visible', async () => {
      await expect(page.getByText('Synced 55 of 58 products to QuickBooks (3 failed)')).toBeVisible();
    });

    test('LP-DASH-065 | Entry "Created product Awesome Watch" is visible', async () => {
      await expect(page.getByText('Created product Awesome Watch')).toBeVisible();
    });

    test('LP-DASH-066 | "sync" tag is visible on a sync entry', async () => {
      await expect(page.getByText('sync').first()).toBeVisible();
    });

    test('LP-DASH-067 | "Product" type label is visible on product entries', async () => {
      await expect(page.getByText('Product').first()).toBeVisible();
    });
  });

  // ─── 10. SETUP CHECKLIST ──────────────────────────────────────────────────

  test.describe('10. Setup Checklist Widget', () => {
    test('LP-DASH-068 | "Setup checklist" heading is visible', async () => {
      await expect(page.getByText('Setup checklist')).toBeVisible();
    });

    test('LP-DASH-069 | "Connect WooCommerce" item is present and struck-through (completed)', async () => {
      const item = page.getByText('Connect WooCommerce');
      await expect(item).toBeVisible();
    });

    test('LP-DASH-070 | "Connect QuickBooks" item is present and struck-through (completed)', async () => {
      const item = page.getByText('Connect QuickBooks');
      await expect(item).toBeVisible();
    });

    test('LP-DASH-071 | "Configure sync settings" item is present and struck-through (completed)', async () => {
      const item = page.getByText('Configure sync settings');
      await expect(item).toBeVisible();
    });

    test('LP-DASH-072 | "Enable automatic sync" item is present and struck-through (completed)', async () => {
      const item = page.getByText('Enable automatic sync');
      await expect(item).toBeVisible();
    });

    test('LP-DASH-073 | All 4 checklist items show a completion indicator (checkmark/icon)', async () => {
      const checkmarks = page.locator('.setup-checklist svg, .checklist-item svg, [class*="checklist"] svg');
      await expect(checkmarks).toHaveCount(4);
    });
  });

  // ─── 11. CONNECTIONS WIDGET ───────────────────────────────────────────────

  test.describe('11. Connections Widget', () => {
    test('LP-DASH-074 | "Connections" heading is visible', async () => {
      await expect(page.getByText('Connections')).toBeVisible();
    });

    test('LP-DASH-075 | "QuickBooks" connection is listed', async () => {
      await expect(page.getByText('QuickBooks')).toBeVisible();
    });

    test('LP-DASH-076 | QuickBooks shows "Connected" status', async () => {
      const qbSection = page.getByText('QuickBooks').locator('..').locator('..');
      await expect(qbSection.getByText('Connected')).toBeVisible();
    });

    test('LP-DASH-077 | "WooCommerce" connection is listed', async () => {
      await expect(page.getByText('WooCommerce')).toBeVisible();
    });

    test('LP-DASH-078 | WooCommerce shows "Connected" status', async () => {
      const wcSection = page.getByText('WooCommerce').last().locator('..').locator('..');
      await expect(wcSection.getByText('Connected').first()).toBeVisible();
    });

    test('LP-DASH-079 | Settings gear icon is present for QuickBooks connection', async () => {
      const qbSection = page.getByText('QuickBooks').locator('..').locator('..');
      await expect(qbSection.locator('svg, button[aria-label*="settings"], .gear-icon').first()).toBeVisible();
    });

    test('LP-DASH-080 | Settings gear icon is present for WooCommerce connection', async () => {
      const wcSection = page.getByText('WooCommerce').last().locator('..').locator('..');
      await expect(wcSection.locator('svg, button[aria-label*="settings"], .gear-icon').first()).toBeVisible();
    });

    test('LP-DASH-081 | QuickBooks avatar/initial "Q" is visible', async () => {
      await expect(page.getByText('Q').first()).toBeVisible();
    });

    test('LP-DASH-082 | WooCommerce avatar/initial "W" is visible', async () => {
      await expect(page.getByText('W').first()).toBeVisible();
    });
  });

  // ─── 12. CONFIGURATION WIDGET ─────────────────────────────────────────────

  test.describe('12. Configuration Widget', () => {
    test('LP-DASH-083 | "Configuration" heading is visible', async () => {
      await expect(page.getByText('Configuration')).toBeVisible();
    });

    test('LP-DASH-084 | "Method" label is visible', async () => {
      await expect(page.getByText('Method')).toBeVisible();
    });

    test('LP-DASH-085 | Method value "Sales Receipt" is displayed', async () => {
      await expect(page.getByText('Sales Receipt')).toBeVisible();
    });

    test('LP-DASH-086 | "Frequency" label is visible', async () => {
      await expect(page.getByText('Frequency')).toBeVisible();
    });

    test('LP-DASH-087 | Frequency value "Hourly" is displayed', async () => {
      await expect(page.getByText('Hourly')).toBeVisible();
    });

    test('LP-DASH-088 | "Auto sync" label is visible', async () => {
      await expect(page.getByText('Auto sync')).toBeVisible();
    });

    test('LP-DASH-089 | Auto sync value "Automatic" is displayed', async () => {
      await expect(page.getByText('Automatic')).toBeVisible();
    });

    test('LP-DASH-090 | Configuration rows each have an icon', async () => {
      const configSection = page.getByText('Configuration').locator('..').locator('..');
      const icons = configSection.locator('svg, img');
      // At least 3 icons for Method, Frequency, Auto sync
      const count = await icons.count();
      expect(count).toBeGreaterThanOrEqual(3);
    });

    test('LP-DASH-091 | "Manage settings →" link is visible', async () => {
      const link = page.getByRole('link', { name: /manage settings/i });
      await expect(link).toBeVisible();
    });

    test('LP-DASH-092 | "Manage settings →" link navigates to Sync Config page', async () => {
      const link = page.getByRole('link', { name: /manage settings/i });
      const href = await link.getAttribute('href');
      expect(href).toContain('ledgerport');
    });
  });

  // ─── 13. SIDEBAR NAVIGATION ───────────────────────────────────────────────

  test.describe('13. Sidebar Navigation', () => {
    test('LP-DASH-093 | "LedgerPort" menu group label is visible in the sidebar', async () => {
      await expect(page.locator('#adminmenu').getByText('LedgerPort')).toBeVisible();
    });

    test('LP-DASH-094 | Sidebar sub-label "WooCommerce Sync" is visible', async () => {
      await expect(page.locator('#adminmenu').getByText('WooCommerce Sync')).toBeVisible();
    });

    test('LP-DASH-095 | "Dashboard" menu item is visible and marked active', async () => {
      const item = page.locator('#adminmenu').getByRole('link', { name: /^dashboard$/i }).first();
      await expect(item).toBeVisible();
    });

    test('LP-DASH-096 | "Connection" menu item is visible in sidebar', async () => {
      const item = page.locator('#adminmenu').getByRole('link', { name: /^connection$/i });
      await expect(item).toBeVisible();
    });

    test('LP-DASH-097 | "Mappings" menu item is visible in sidebar', async () => {
      const item = page.locator('#adminmenu').getByRole('link', { name: /^mappings$/i });
      await expect(item).toBeVisible();
    });

    test('LP-DASH-098 | "Manual Sync" menu item is visible in sidebar', async () => {
      const item = page.locator('#adminmenu').getByRole('link', { name: /^manual sync$/i });
      await expect(item).toBeVisible();
    });

    test('LP-DASH-099 | "Audit Logs" menu item is visible in sidebar', async () => {
      const item = page.locator('#adminmenu').getByRole('link', { name: /^audit logs$/i });
      await expect(item).toBeVisible();
    });

    test('LP-DASH-100 | "Sync Config" menu item is visible in sidebar', async () => {
      const item = page.locator('#adminmenu').getByRole('link', { name: /^sync config$/i });
      await expect(item).toBeVisible();
    });

    test('LP-DASH-101 | "Debug Logs" menu item is visible in sidebar', async () => {
      const item = page.locator('#adminmenu').getByRole('link', { name: /^debug logs$/i });
      await expect(item).toBeVisible();
    });

    test('LP-DASH-102 | "Connection" menu link navigates to Connection page', async () => {
      const link = page.locator('#adminmenu').getByRole('link', { name: /^connection$/i });
      const href = await link.getAttribute('href');
      expect(href).toContain('ledgerport-connection');
    });

    test('LP-DASH-103 | "Mappings" menu link navigates to Mappings page', async () => {
      const link = page.locator('#adminmenu').getByRole('link', { name: /^mappings$/i });
      const href = await link.getAttribute('href');
      expect(href).toContain('ledgerport-mappings');
    });

    test('LP-DASH-104 | "Manual Sync" menu link navigates to Manual Sync page', async () => {
      const link = page.locator('#adminmenu').getByRole('link', { name: /^manual sync$/i });
      const href = await link.getAttribute('href');
      expect(href).toContain('ledgerport-manual-sync');
    });

    test('LP-DASH-105 | "Audit Logs" menu link navigates to Audit Logs page', async () => {
      const link = page.locator('#adminmenu').getByRole('link', { name: /^audit logs$/i });
      const href = await link.getAttribute('href');
      expect(href).toContain('ledgerport-audit-logs');
    });

    test('LP-DASH-106 | "Sync Config" menu link navigates to Sync Config page', async () => {
      const link = page.locator('#adminmenu').getByRole('link', { name: /^sync config$/i });
      const href = await link.getAttribute('href');
      expect(href).toContain('ledgerport-sync-config');
    });

    test('LP-DASH-107 | "Debug Logs" menu link navigates to Debug Logs page', async () => {
      const link = page.locator('#adminmenu').getByRole('link', { name: /^debug logs$/i });
      const href = await link.getAttribute('href');
      expect(href).toContain('ledgerport-debug-logs');
    });
  });

  // ─── 14. FOOTER ───────────────────────────────────────────────────────────

  test.describe('14. Footer', () => {
    test('LP-DASH-108 | WordPress footer text "Thank you for creating with WordPress." is visible', async () => {
      await expect(page.getByText(/Thank you for creating with/i)).toBeVisible();
    });

    test('LP-DASH-109 | WordPress footer contains a "WordPress" link', async () => {
      const wpLink = page.locator('#wpfooter').getByRole('link', { name: /wordpress/i });
      await expect(wpLink).toBeVisible();
    });

    test('LP-DASH-110 | WordPress version number is shown in the footer', async () => {
      await expect(page.locator('#wpfooter').getByText(/Version \d+\.\d+/i)).toBeVisible();
    });
  });

  // ─── 15. RESPONSIVE / ACCESSIBILITY ──────────────────────────────────────

  test.describe('15. Accessibility & Layout', () => {
    test('LP-DASH-111 | All clickable links have a non-empty href', async () => {
      const links = await page.locator('a[href]').all();
      for (const link of links) {
        const href = await link.getAttribute('href');
        expect(href).toBeTruthy();
      }
    });

    test('LP-DASH-112 | LedgerPort logo image has an alt attribute', async () => {
      const logo = page.locator('.ledgerport-logo img, header img[alt]').first();
      const alt = await logo.getAttribute('alt');
      expect(alt).not.toBeNull();
      expect(alt!.length).toBeGreaterThan(0);
    });

    test('LP-DASH-113 | "Sync now" button is keyboard-focusable', async () => {
      await page.keyboard.press('Tab');
      const focusedTag = await page.evaluate(() => document.activeElement?.tagName);
      // Tab key moves focus — just confirm the page responds to keyboard navigation
      expect(focusedTag).toBeTruthy();
    });

    test('LP-DASH-114 | No duplicate page headings for "Overview"', async () => {
      const headings = await page.getByRole('heading', { name: /overview/i }).count();
      expect(headings).toBe(1);
    });
  });
});
