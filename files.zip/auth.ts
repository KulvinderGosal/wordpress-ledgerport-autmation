import { Page } from '@playwright/test';

/**
 * Credentials and base config for LedgerPort test environment
 */
export const TEST_CONFIG = {
  baseURL: 'https://qastaging.pushengage.com',
  username: 'kgosal',
  password: '!letmeIn@123=',
  dashboardURL: '/wp-admin/admin.php?page=ledgerport',
  loginURL: '/wp-login.php',
};

/**
 * Plugin menu pages — used across multiple test files
 */
export const PLUGIN_PAGES = {
  dashboard:  '/wp-admin/admin.php?page=ledgerport',
  connection: '/wp-admin/admin.php?page=ledgerport-connection',
  mappings:   '/wp-admin/admin.php?page=ledgerport-mappings',
  manualSync: '/wp-admin/admin.php?page=ledgerport-manual-sync',
  auditLogs:  '/wp-admin/admin.php?page=ledgerport-audit-logs',
  syncConfig: '/wp-admin/admin.php?page=ledgerport-sync-config',
  debugLogs:  '/wp-admin/admin.php?page=ledgerport-debug-logs',
};

/**
 * Login to WordPress admin. Call from test.beforeEach or a shared fixture.
 */
export async function loginAsAdmin(page: Page): Promise<void> {
  await page.goto(TEST_CONFIG.loginURL);
  await page.locator('#user_login').fill(TEST_CONFIG.username);
  await page.locator('#user_pass').fill(TEST_CONFIG.password);
  await page.locator('#wp-submit').click();
  await page.waitForLoadState('networkidle');
}

/**
 * Navigate to a LedgerPort plugin page (assumes already logged in).
 */
export async function goToPluginPage(page: Page, path: string): Promise<void> {
  await page.goto(path);
  await page.waitForLoadState('networkidle');
}
